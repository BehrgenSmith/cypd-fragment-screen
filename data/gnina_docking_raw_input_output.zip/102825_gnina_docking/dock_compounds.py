import subprocess
import logging
from pathlib import Path
import time
import os
from concurrent.futures import ProcessPoolExecutor, as_completed

N_CPU = 7

RECEPTOR = "102825_8UC5_pandas_superposed.pdb"

LIG_DIR = Path("102225_cypd_uniq_lig_sdf")
STDOUT_DIR = Path("logs/stdout")
STDERR_DIR = Path("logs/stderr")
RESULT_DIR = Path("docking_results")

for d in [LIG_DIR, STDOUT_DIR, STDERR_DIR, RESULT_DIR]:
    d.mkdir(exist_ok=True, parents=True)

container_name = "gnina_batch"

# Start persistent container
subprocess.run(
    f"docker run -d --rm --name {container_name} "
    f"-v $(pwd):/scr -w /scr gnina/gnina sleep infinity",
    shell=True,
    check=True,
)

logging.basicConfig(
    level=logging.DEBUG,
    format="%(asctime)s | %(levelname)-8s | %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
    filename="docking.log",
    filemode="w",
)
logger = logging.getLogger("gnina_docking")


def dock_single(lig_f: Path):
    """Run gnina docking for a single ligand file."""
    stdout_file = Path("logs") / f"{lig_f.stem}.log"
    stderr_file = STDERR_DIR / f"{lig_f.stem}.err"
    output_name = RESULT_DIR / f"{lig_f.stem}_docked.sdf"

    cmd = (
        f"docker exec "
        f"-e OMP_NUM_THREADS=1 -e OPENBLAS_NUM_THREADS=1 -e MKL_NUM_THREADS=1 "
        f"{container_name} "
        f"gnina -r /scr/{RECEPTOR} -l /scr/{lig_f} --no_gpu "
        f"--config 102925_cypd_gnina_config.txt -o /scr/{output_name} --log {stdout_file}"
    )

    start_time = time.perf_counter()
    try:
        result = subprocess.run(
            cmd, shell=True, check=True, capture_output=True, text=True
        )

        elapsed = time.perf_counter() - start_time
        with open(stdout_file, "w") as out, open(stderr_file, "w") as err:
            out.write(result.stdout or "")
            err.write(result.stderr or "")
        logger.info(f"Docked {lig_f.name} → {output_name} in {elapsed:.2f} s")
    except subprocess.CalledProcessError as e:
        elapsed = time.perf_counter() - start_time
        logger.error(f"Error docking {lig_f.name} (after {elapsed:.2f} s)")
        logger.error(f"Command: {cmd}")
        logger.error(f"Return code: {e.returncode}")
        logger.error(f"STDOUT:\n{e.stdout}")
        logger.error(f"STDERR:\n{e.stderr}")


# Run up to N_CPU dockings concurrently
lig_files = sorted(LIG_DIR.iterdir())
logger.info(f"Found {len(lig_files)} ligands, running {N_CPU} in parallel.")

try:
    with ProcessPoolExecutor(max_workers=N_CPU) as executor:
        futures = {executor.submit(dock_single, lig): lig for lig in lig_files}
        for future in as_completed(futures):
            lig = futures[future]
            try:
                future.result()
            except Exception as exc:
                logger.error(f"{lig.name} generated an exception: {exc}")

finally:
    subprocess.run(f"docker stop {container_name}", shell=True)
    logger.info("🪦 Stopped container and finished batch docking.")
